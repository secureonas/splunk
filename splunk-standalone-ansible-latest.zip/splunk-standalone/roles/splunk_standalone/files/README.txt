Place your Splunk Enterprise installers here:
  - splunk-10.0.0-<build>-linux-2.6-amd64.deb   (Debian/Ubuntu)
  - splunk-10.0.0-<build>.x86_64.rpm            (RHEL/Rocky/Alma)

The role parses the version/build from the filename automatically.
Update the filenames in group_vars/splunk_standalone.yml to match.
