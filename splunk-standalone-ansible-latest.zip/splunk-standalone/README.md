# Splunk Enterprise — Standalone Bootstrap (one-time, local)

Run this ONCE on a fresh Splunk host to install and configure a standalone
Splunk Enterprise 10.x instance correctly. Ansible runs locally on the box
itself — no SSH, no control node needed.

## What it does
- Installs from a LOCAL package (no internet required)
- Creates a non-root `splunk` user and sets ownership
- Configures ulimits (systemd drop-in + limits.d) + disables THP
- Enables boot-start via systemd (with polkit) — auto-detects init system
- Enables SSL S2S receiving on 9997 (matches the forwarder apps' SSL output)
- Seeds the admin password on first run, then DELETES the seed file
- Creates custom indexes (app `app_indexes`): windows, linux, o365, fw, av,
  iis, network — 2TB cap, 1-year retention
- Layer 2 (Ubuntu syslog): /syslog dir, rsyslog drop-in (UDP+TCP 514),
  AppArmor override, splunk in `adm` group, logrotate
- Layer 3 (web + DS): Splunk Web on 443 via iptables redirect; deployment
  server with SendToIndexerNix/Win apps + serverclass
- Installs TAs into etc/apps (CIM, Splunk_TA_nix, Splunk_TA_windows) and
  creates linux/windows deployment input apps (pushed to forwarders)
- Waits for splunkd and validates status
- Safe to re-run: already-current installs skip install but still apply config

## Prerequisites (on the Splunk host)
1. Install Ansible and supporting tools:
   - Ubuntu/Debian:  `apt install -y ansible vim unzip`
   - RHEL/Rocky:     `dnf install -y ansible-core vim unzip`
2. Install the required collection:
   ```
   ansible-galaxy collection install -r requirements.yml
   ```

## Setup
1. Copy this whole folder onto the Splunk host (e.g. /root/splunk-standalone)
2. Drop the installer into `roles/splunk_standalone/files/`
   (`.deb` for Ubuntu/Debian, `.rpm` for RHEL/Rocky)
3. Edit `group_vars/splunk_standalone.yml`:
   - `splunk_role` — **`full`** (everything) or **`indexer`** (bare indexer:
     install + ulimits + THP + service + 9997 receiving only; all other
     layers forced off)
   - `splunk_pkg_deb` — package filename to match what you dropped in
   - `splunk_admin_password` — a strong admin password
   - **`splunk_indexer_ip`** — THIS server's IP address. The deployment-server
     apps point forwarders here for data. *** MUST be updated per deployment ***
     (e.g. change `192.168.203.134` to your server's IP)

   Layer toggles (all default true) — set false to skip a layer per client:
   - `splunk_configure_syslog`            — /syslog + rsyslog receiver
   - `splunk_web_443`                     — iptables 443->8443 + SSL web
   - `splunk_configure_deployment_server` — SendToIndexer apps + serverclass
   - `splunk_configure_indexes`           — custom indexes app
   - `splunk_configure_apps`              — TAs + deployment input apps

   App source (TAs): `splunk_apps_source`
   - `url`   — download from `splunk_apps_base_url` (lab / has internet).
               Needs github.com + raw.githubusercontent.com reachable.
   - `local` — read archives from roles/splunk_standalone/files/ (air-gapped).
               Place the .tgz/.spl files there and set this to "local".

## Run (on the Splunk host)
```bash
cd splunk-standalone

# Dry run first — shows what would change, makes no changes
ansible-playbook site.yml --check --diff

# Real run
ansible-playbook site.yml
```

That's it. After it completes, Splunk is installed, running, set to
start on boot, and ready to receive forwarder data on 9997.

## Verify / troubleshoot

```bash
# Watch what Splunk does as it starts (most useful when debugging startup)
sudo journalctl -u Splunkd -n 100 --no-pager

# Follow live (Ctrl-C to stop)
sudo journalctl -u Splunkd -f

# Service state and process tree
systemctl status Splunkd --no-pager

# Confirm ports are listening (8000 web, 8089 mgmt, 9997 receiving)
ss -tlnp | grep -E "8000|8089|9997"

# Confirm the splunk user can run the CLI
sudo -u splunk /opt/splunk/bin/splunk status

# Confirm resource limits took effect (should be 16384 / 65536)
cat /proc/$(pgrep -f "splunkd.*under-systemd" | head -1)/limits | grep -E "processes|open files"

# Splunk's own startup/internal log
sudo tail -50 /opt/splunk/var/log/splunk/splunkd.log
```

## Notes
- The admin password is only used to seed the account on first start;
  the plaintext seed file is removed immediately afterwards.
- For a production client, encrypt the password:
  `ansible-vault encrypt_string 'YourPass' --name 'splunk_admin_password'`
  and run with `--ask-vault-pass`.
